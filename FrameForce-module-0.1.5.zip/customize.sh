ui_print "- Installing FrameForce by bababoi"
# Retire the previous module ID and carry its rollback data forward on upgrade.
OLD_MOD=/data/adb/modules/fo-frameforce
OLD_DATA=/data/adb/fo-frameforce
NEW_DATA=/data/adb/frameforce
[ ! -d "$OLD_MOD" ] || touch "$OLD_MOD/disable"
if [ -d "$OLD_DATA" ] && [ ! -e "$NEW_DATA" ]; then mv "$OLD_DATA" "$NEW_DATA"; fi
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/action.sh" 0 0 0755
set_perm "$MODPATH/frameforce_apply.sh" 0 0 0755
set_perm "$MODPATH/restore.sh" 0 0 0755
ui_print "- Includes systemless Game Cube XML overlays; a metamodule is required"
ui_print "- Adds the database whitelist at boot after Game Cube creates its databases"
ui_print "- Manual rerun: tap Action in the module manager"
