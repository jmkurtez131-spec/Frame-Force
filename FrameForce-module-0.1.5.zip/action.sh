#!/system/bin/sh
MODDIR=${0%/*}
TARGET=$(settings --user 0 get secure frameforce_target_fps 2>/dev/null)
if [ "$TARGET" = "120" ]; then RENDERED=60; OUTPUT=120; else TARGET=90; RENDERED=72; OUTPUT=144; fi
exec /system/bin/sh "$MODDIR/frameforce_apply.sh" "${TARGET:-90}" "${RENDERED:-72}" "${OUTPUT:-144}"
