# FrameForce 0.1.5 by bababoi

This is the FrameForce KernelSU module by bababoi. It includes systemless Game Cube XML overlays and a whitelist script. The paired APK contains the LSPosed hook. It does not include thermal unlocks, frequency controls, or a daemon.

## What it configures

- The paired app selects either `90 → 72 → 144` or `120 → 60 → 120`; the app saves the selected profile and the boot/Action scripts reuse it.
- Super-resolution whitelist row: the source defaults (`state=2`, `ultra_resolution=2K`).
- Game Cube dimension whitelist, including `boost_frame_v3_90_72_144`.
- Existing interpolation rows receive the selected profile in the database, while the LSPosed hook preserves Game Cube's existing XML profile list and fills only missing values.
- The XML overlay carries the target device's Game Cube configuration; the LSPosed hook patches parsed configs for installed apps that are absent from those base files.

The script targets games already listed in Vivo Game Cube and installed third-party apps. It needs root, `nsenter`, `sqlite3` on `/system/bin`, `/vendor/bin`, or `/product/bin`, and Game Cube's databases. Open Game Cube once before using the module. It changes Vivo Game Cube's private databases and does not create frame interpolation or super-resolution support if the device firmware/GPU does not provide those features.

## Install and run

Install the ZIP in the KernelSU manager with a compatible metamodule already active, then reboot. At boot the module overlays the two Game Cube XML files and waits for Game Cube's frame-interpolation database before running the whitelist script once. Install the paired APK, enable FrameForce in LSPosed for `com.vivo.gamecube`, then tap **Apply whitelist** and restart Game Cube. To rerun the database script after Game Cube overwrites its database, use the module's **Action** button. Output is written to `/data/adb/frameforce/whitelist.log`.

This package is intended for the KernelSU manager, not custom recovery. The XML files are specifically for iQOO Neo10 Pro+ (PD2463 / V2463A), Snapdragon 8 Elite, OriginOS 6 / Android 16; other devices and OS versions are unverified. If the original `fuckorigin-thermal` module is active, disable it before enabling this module because both overlay the same Game Cube XML paths. The LSPosed hook does not spoof temperature or disable the phone's thermal controls. Before applying, the script creates timestamped SQLite-consistent copies of all four Game Cube databases under `/data/adb/frameforce/backups/`. Preserve those files if you may want to restore the original rows.

The APK's **Revert to original settings** button restores the first complete database snapshot, disables the LSPosed hook, and marks this module disabled. Reboot to remove the XML overlay. The baseline is stored at `/data/adb/frameforce/backups/baseline`; pre-run history snapshots are stored under `backups/history/`. Removing the module alone removes its XML overlay but leaves database changes in place.
