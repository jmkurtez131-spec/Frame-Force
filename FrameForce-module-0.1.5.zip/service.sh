#!/system/bin/sh
MODDIR=${0%/*}
LOGDIR=/data/adb/frameforce
DBDIR=/data/user/0/com.vivo.gamecube/databases
mkdir -p "$LOGDIR"

until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 2; done

# Game Cube may create its private databases only after first launch. Wait up
# to ten minutes, then apply once; use the module Action button for a later run.
i=0
while ! nsenter -t 1 -m -- test -f "$DBDIR/frame_inter_list.db"; do
  [ "$i" -ge 120 ] && {
    echo "$(date): Game Cube database not found; open Game Cube and rerun Action" >> "$LOGDIR/whitelist.log"
    exit 0
  }
  sleep 5
  i=$((i+1))
done

TARGET=$(settings --user 0 get secure frameforce_target_fps 2>/dev/null)
if [ "$TARGET" = "120" ]; then RENDERED=60; OUTPUT=120; else TARGET=90; RENDERED=72; OUTPUT=144; fi
/system/bin/sh "$MODDIR/frameforce_apply.sh" "${TARGET:-90}" "${RENDERED:-72}" "${OUTPUT:-144}" >> "$LOGDIR/whitelist.log" 2>&1
echo "$(date): whitelist script exit=$?" >> "$LOGDIR/whitelist.log"
