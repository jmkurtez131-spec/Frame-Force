#!/system/bin/sh
# 为"游戏魔盒里添加的应用 + 已安装第三方应用"补齐超分/插帧/维度白名单（可重复执行）
export PATH=/system/bin:/vendor/bin:/product/bin:$PATH
B=/data/user/0/com.vivo.gamecube/databases
TMP=/data/local/tmp/fo_wl
TARGET=${1:-90}
RENDERED=${2:-72}
OUTPUT=${3:-144}
case "$TARGET:$RENDERED:$OUTPUT" in
  90:72:144|120:60:120) ;;
  *) echo "unsupported profile: $TARGET:$RENDERED:$OUTPUT" >&2; exit 2 ;;
esac
mkdir -p "$TMP"

command -v nsenter >/dev/null 2>&1 || { echo "nsenter is required" >&2; exit 1; }
command -v sqlite3 >/dev/null 2>&1 || { echo "sqlite3 is required on PATH" >&2; exit 1; }
db_exists() { nsenter -t 1 -m -- test -f "$1"; }

for db in game_cube.db super_resolution_list.db frame_inter_list.db support_dimension_list.db; do
  if ! db_exists "$B/$db"; then
    echo "missing Game Cube database: $B/$db (open Game Cube once, then rerun)" >&2
    exit 1
  fi
done

q() { nsenter -t 1 -m -- sqlite3 "$1" "$2"; }
cnt() { q "$1" "select count(*) from $2 where pkg_name='$3'"; }
require_columns() {
  db=$1; table=$2; shift 2
  for column do
    if [ "$(q "$db" "select count(*) from pragma_table_info('$table') where name='$column'")" != "1" ]; then
      echo "missing schema: $db $table.$column" >&2
      exit 1
    fi
  done
}

require_columns "$B/game_cube.db" supportGamesTable package_name
require_columns "$B/game_cube.db" operatedSupportGamesTable package_name
require_columns "$B/game_cube.db" funcTable package_name
require_columns "$B/super_resolution_list.db" super_resolution_support_game pkg_name label channel state frame_depress frame_inter monster_frame_depress monster_frame_inter over_heat_temperature cool_down_temperature over_heat_temperature_extreme cool_down_temperature_extreme game_index high_frame_depress high_frame_inter monster_plus_state ultra_resolution
require_columns "$B/frame_inter_list.db" frame_inter_support_game pkg_name label channel game_index support_sdk monster_plus_state over_heat_temperature cool_down_temperature temperature_type boost_frame_values opti_power_values frame_rate_tip
require_columns "$B/support_dimension_list.db" game_dimen function type pkg_name label channel oversea game_index support_sdk frame_inter_value

# Preserve the original databases once, then keep a snapshot before every run.
DATA=/data/adb/frameforce
BACKUPS=$DATA/backups
BASELINE=$BACKUPS/baseline
HISTORY=$BACKUPS/history/$(date +%Y%m%d-%H%M%S)-$$
mkdir -p "$HISTORY"
chmod 700 "$DATA" "$BACKUPS" "$BACKUPS/history" "$HISTORY"
if [ ! -f "$BASELINE/complete" ]; then
  mkdir -p "$BASELINE"
  chmod 700 "$BASELINE"
  # Migrate the earliest timestamped backup created by 0.1.0, if present.
  LEGACY=$(ls -1dt "$BACKUPS"/20* 2>/dev/null | tail -n 1)
  migrated=1
  if [ -n "$LEGACY" ]; then
    for db in game_cube.db super_resolution_list.db frame_inter_list.db support_dimension_list.db; do
      [ -f "$LEGACY/$db" ] || migrated=0
    done
  else
    migrated=0
  fi
  if [ "$migrated" = "1" ]; then
    cp -f "$LEGACY"/*.db "$BASELINE/" || { echo "baseline migration failed" >&2; exit 1; }
  else
    for db in game_cube.db super_resolution_list.db frame_inter_list.db support_dimension_list.db; do
      nsenter -t 1 -m -- sqlite3 "$B/$db" ".backup '$BASELINE/$db'" || { echo "baseline backup failed: $db" >&2; exit 1; }
    done
  fi
  for db in game_cube.db super_resolution_list.db frame_inter_list.db support_dimension_list.db; do chmod 600 "$BASELINE/$db"; done
  touch "$BASELINE/complete"
fi
for db in game_cube.db super_resolution_list.db frame_inter_list.db support_dimension_list.db; do
  nsenter -t 1 -m -- sqlite3 "$B/$db" ".backup '$HISTORY/$db'" || { echo "database backup failed: $db" >&2; exit 1; }
  chmod 600 "$HISTORY/$db"
done
touch "$HISTORY/complete"
echo "rollback baseline: $BASELINE"
echo "pre-run snapshot: $HISTORY"

q "$B/game_cube.db" "select package_name from supportGamesTable union select package_name from operatedSupportGamesTable" > "$TMP/t.txt"
pm list packages -3 2>/dev/null | sed 's/package://' >> "$TMP/t.txt"
sort -u "$TMP/t.txt" -o "$TMP/t.txt"

for file in sr fi dm gc; do
  printf '.bail on\n.timeout 5000\nBEGIN IMMEDIATE;\n' > "$TMP/$file.sql"
done
BOOST="[{\"a\":$TARGET,\"b\":$RENDERED,\"c\":$OUTPUT}]"
OPTI='[{"a":60,"b":30,"c":60},{"a":90,"b":45,"c":90},{"a":120,"b":60,"c":120}]'
if [ "$TARGET" = "120" ]; then
  TIP='{"120":{"tipStringName":"num_120","tipString":"120fps"}}'
else
  TIP='{"90":{"tipStringName":"zhen_90","tipString":"90fps"}}'
fi

while read -r p; do
  [ -z "$p" ] && continue
  case "$p" in *[!A-Za-z0-9._]* ) continue ;; esac
  if [ "$(cnt "$B/super_resolution_list.db" super_resolution_support_game "$p")" = "0" ]; then
    cat >> $TMP/sr.sql <<SQL
INSERT INTO super_resolution_support_game(pkg_name,label,channel,state,frame_depress,frame_inter,monster_frame_depress,monster_frame_inter,over_heat_temperature,cool_down_temperature,over_heat_temperature_extreme,cool_down_temperature_extreme,game_index,high_frame_depress,high_frame_inter,monster_plus_state,ultra_resolution) VALUES('$p','$p','#',2,30,60,-1,-1,-1.0,-1.0,47.0,44.0,3,-1,-1,0,'2K');
SQL
  else
    # Preserve per-device thresholds while enabling the source's 2K SR mode.
    echo "UPDATE super_resolution_support_game SET state=2, ultra_resolution='2K' WHERE pkg_name='$p';" >> "$TMP/sr.sql"
  fi
  if [ "$(cnt "$B/frame_inter_list.db" frame_inter_support_game "$p")" = "0" ]; then
    cat >> $TMP/fi.sql <<SQL
INSERT INTO frame_inter_support_game(pkg_name,label,channel,game_index,support_sdk,monster_plus_state,over_heat_temperature,cool_down_temperature,temperature_type,boost_frame_values,opti_power_values,frame_rate_tip) VALUES('$p','$p','#',3,0,0,-1.0,-1.0,0,'$BOOST','$OPTI','$TIP');
SQL
  else
    # Existing rows must be updated too; otherwise rerunning the script keeps
    # their old interpolation profile instead of the requested 90 -> 72 -> 144.
    echo "UPDATE frame_inter_support_game SET boost_frame_values='$BOOST' WHERE pkg_name='$p';" >> $TMP/fi.sql
  fi
  # Add missing dimensions individually; a package may already have some rows.
  for f in competition_mode super_resolution boost_frame optimize_power boost_frame_v3_60_120 boost_frame_v3_60_48_144 boost_frame_v3_90_72_144 game_filter_for_iris game_super_hd_engine screen_light_effect; do
    if [ "$(q "$B/support_dimension_list.db" "select count(*) from game_dimen where pkg_name='$p' and function='$f'")" = "0" ]; then
      echo "INSERT INTO game_dimen(function,type,pkg_name,label,channel,oversea,game_index,support_sdk,frame_inter_value) VALUES('$f','white','$p','$p','*',0,-1,0,-1);" >> $TMP/dm.sql
    fi
  done
  if [ "$(q "$B/game_cube.db" "select count(*) from funcTable where package_name='$p'")" = "0" ]; then
    echo "INSERT INTO funcTable(package_name,change_voice,count_down,count_down_type,framework_hook,gamewatch_hook,competition_mode,super_audio_effects,super_audio_type,data_1,voice_command,back_record,double_play,double_pkg_name,double_pkg_main_body,death_replay) VALUES('$p','*','','','','','*','#','7','','*','','','','true','*');" >> $TMP/gc.sql
  fi
done < "$TMP/t.txt"

for file in sr fi dm gc; do echo 'COMMIT;' >> "$TMP/$file.sql"; done
nsenter -t 1 -m -- sqlite3 "$B/super_resolution_list.db" < "$TMP/sr.sql" || exit 1
nsenter -t 1 -m -- sqlite3 "$B/frame_inter_list.db" < "$TMP/fi.sql" || exit 1
nsenter -t 1 -m -- sqlite3 "$B/support_dimension_list.db" < "$TMP/dm.sql" || exit 1
nsenter -t 1 -m -- sqlite3 "$B/game_cube.db" < "$TMP/gc.sql" || exit 1
echo "whitelist ok: SR=$(q "$B/super_resolution_list.db" 'select count(*) from super_resolution_support_game') FI=$(q "$B/frame_inter_list.db" 'select count(*) from frame_inter_support_game') DIMEN=$(q "$B/support_dimension_list.db" 'select count(*) from game_dimen')"
