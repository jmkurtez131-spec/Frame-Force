package de.robv.android.xposed;

public final class XposedHelpers {
    public static Class<?> findClassIfExists(String name, ClassLoader loader) { return null; }
    public static void setBooleanField(Object instance, String fieldName, boolean value) { }
    public static void setIntField(Object instance, String fieldName, int value) { }
    public static XC_MethodHook.Unhook findAndHookMethod(String className, ClassLoader loader,
            String methodName, Object... parameterTypesAndCallback) { return null; }
    public static XC_MethodHook.Unhook findAndHookMethod(Class<?> clazz, String methodName,
            Object... parameterTypesAndCallback) { return null; }
}
