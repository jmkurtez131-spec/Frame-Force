package com.bababoi.frameforce;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private TextView output;
    private TextView targetValue;
    private TextView renderedValue;
    private TextView interpolatedValue;
    private TextView mode90;
    private TextView mode120;
    private Button apply;
    private Button disable;
    private Button revert;
    private TextView requirementStatus;
    private CheckBox scopeCheck;
    private boolean requirementsMet;
    private boolean scopeConfirmed;
    private int targetFps = 90;
    private int renderedFps = 72;
    private int outputFps = 144;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(9, 14, 22));
        getWindow().setNavigationBarColor(Color.rgb(9, 14, 22));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(9, 14, 22));

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(28), dp(22), dp(26));
        scroll.addView(page);

        TextView eyebrow = label("FRAMEFORCE  /  BY BABABOI", 11, Color.rgb(98, 220, 192));
        eyebrow.setLetterSpacing(0.11f);
        page.addView(eyebrow);

        TextView title = label("FrameForce", 32, Color.WHITE);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        LinearLayout.LayoutParams titleLp = params(-1, -2, 0, 7);
        page.addView(title, titleLp);

        TextView subtitle = label("Frame interpolation and super-resolution", 14, Color.rgb(151, 165, 185));
        page.addView(subtitle);

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(18), dp(17), dp(18), dp(17));
        hero.setBackground(rounded(Color.rgb(18, 29, 43), Color.rgb(34, 52, 70), dp(20)));
        LinearLayout.LayoutParams heroLp = params(-1, -2, 0, 23);
        page.addView(hero, heroLp);

        TextView heroCaption = label("INTERPOLATION PROFILE", 11, Color.rgb(144, 161, 183));
        heroCaption.setLetterSpacing(0.08f);
        hero.addView(heroCaption);

        LinearLayout metrics = new LinearLayout(this);
        metrics.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams metricsLp = params(-1, -2, 0, 13);
        hero.addView(metrics, metricsLp);
        targetValue = metric(metrics, "90", "TARGET FPS", true);
        renderedValue = metric(metrics, "72", "RENDERED", false);
        interpolatedValue = metric(metrics, "144", "INTERPOLATED FPS", false);

        LinearLayout modes = new LinearLayout(this);
        modes.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams modesLp = params(-1, dp(40), 13, 0);
        hero.addView(modes, modesLp);
        mode90 = modeChip("90 → 72 → 144");
        mode120 = modeChip("120 → 60 → 120");
        modes.addView(mode90, new LinearLayout.LayoutParams(0, -1, 1));
        LinearLayout.LayoutParams mode120Lp = new LinearLayout.LayoutParams(0, -1, 1);
        mode120Lp.leftMargin = dp(8);
        modes.addView(mode120, mode120Lp);
        mode90.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { selectProfile(90); }
        });
        mode120.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { selectProfile(120); }
        });
        selectProfile(getPreferences(MODE_PRIVATE).getInt("profile_target", 90));

        LinearLayout srRow = new LinearLayout(this);
        srRow.setGravity(Gravity.CENTER_VERTICAL);
        srRow.setPadding(dp(12), dp(10), dp(12), dp(10));
        srRow.setBackground(rounded(Color.rgb(23, 41, 51), 0, dp(12)));
        LinearLayout.LayoutParams srLp = params(-1, -2, 0, 15);
        hero.addView(srRow, srLp);
        TextView srTitle = label("Super-resolution", 14, Color.rgb(219, 230, 240));
        srRow.addView(srTitle, new LinearLayout.LayoutParams(0, -2, 1));
        TextView srValue = label("2K", 13, Color.rgb(98, 220, 192));
        srValue.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        srRow.addView(srValue);

        apply = button("Apply profile", Color.rgb(98, 220, 192), Color.rgb(9, 25, 26));
        LinearLayout.LayoutParams applyLp = params(-1, dp(52), 0, 18);
        page.addView(apply, applyLp);
        apply.setEnabled(false);
        apply.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { applyProfile(); }
        });

        disable = button("Disable LSPosed hooks", Color.rgb(26, 37, 52), Color.rgb(218, 228, 240));
        LinearLayout.LayoutParams disableLp = params(-1, dp(48), 0, 9);
        page.addView(disable, disableLp);
        disable.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { disableHooks(); }
        });

        revert = button("Revert to original settings", Color.rgb(37, 28, 34), Color.rgb(247, 164, 158));
        LinearLayout.LayoutParams revertLp = params(-1, dp(48), 0, 9);
        page.addView(revert, revertLp);
        revert.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { confirmRevert(); }
        });

        TextView hint = label("Enable FrameForce in LSPosed for com.vivo.gamecube. The XML overlay uses your installed metamodule. Restart Game Cube after applying.", 12, Color.rgb(120, 137, 158));
        hint.setLineSpacing(dp(3), 1f);
        LinearLayout.LayoutParams hintLp = params(-1, -2, 0, 19);
        page.addView(hint, hintLp);

        requirementStatus = label("Checking root, LSPosed, Meta Mount, module and Game Cube…", 12, Color.rgb(195, 210, 227));
        requirementStatus.setLineSpacing(dp(3), 1f);
        requirementStatus.setPadding(dp(14), dp(12), dp(14), dp(12));
        requirementStatus.setBackground(rounded(Color.rgb(15, 22, 33), Color.rgb(29, 42, 58), dp(14)));
        page.addView(requirementStatus, params(-1, -2, 14, 0));
        requirementStatus.setClickable(true);
        requirementStatus.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { refreshRequirements(); }
        });
        scopeCheck = new CheckBox(this);
        scopeCheck.setText("FrameForce is enabled in LSPosed for com.vivo.gamecube");
        scopeCheck.setTextColor(Color.rgb(180, 195, 213));
        scopeCheck.setTextSize(12);
        scopeCheck.setButtonTintList(android.content.res.ColorStateList.valueOf(Color.rgb(98, 220, 192)));
        scopeCheck.setChecked(false);
        scopeCheck.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(android.widget.CompoundButton button, boolean checked) {
                scopeConfirmed = checked;
                updateApplyEnabled();
            }
        });
        page.addView(scopeCheck, params(-1, -2, 7, 0));

        output = label("Ready", 12, Color.rgb(195, 210, 227));
        output.setGravity(Gravity.TOP | Gravity.START);
        output.setPadding(dp(14), dp(13), dp(14), dp(13));
        output.setMinHeight(dp(76));
        output.setBackground(rounded(Color.rgb(15, 22, 33), Color.rgb(29, 42, 58), dp(14)));
        LinearLayout.LayoutParams outputLp = params(-1, -2, 0, 13);
        page.addView(output, outputLp);

        setContentView(scroll);
        refreshRequirements();
    }

    private TextView metric(LinearLayout row, String value, String caption, boolean first) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(first ? Gravity.START : Gravity.CENTER);
        row.addView(item, new LinearLayout.LayoutParams(0, -2, 1));
        TextView number = label(value, 28, first ? Color.rgb(98, 220, 192) : Color.WHITE);
        number.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        item.addView(number);
        TextView small = label(caption, 9, Color.rgb(134, 151, 174));
        small.setLetterSpacing(0.06f);
        item.addView(small);
        return number;
    }

    private TextView modeChip(String title) {
        TextView chip = label(title, 12, Color.rgb(205, 217, 230));
        chip.setGravity(Gravity.CENTER);
        chip.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        chip.setBackground(rounded(Color.rgb(23, 34, 48), Color.rgb(39, 56, 75), dp(11)));
        chip.setClickable(true);
        return chip;
    }

    private void selectProfile(int target) {
        if (target == 120) { targetFps = 120; renderedFps = 60; outputFps = 120; }
        else { targetFps = 90; renderedFps = 72; outputFps = 144; }
        if (targetValue != null) {
            targetValue.setText(String.valueOf(targetFps));
            renderedValue.setText(String.valueOf(renderedFps));
            interpolatedValue.setText(String.valueOf(outputFps));
            setChipSelected(mode90, targetFps == 90);
            setChipSelected(mode120, targetFps == 120);
            getPreferences(MODE_PRIVATE).edit().putInt("profile_target", targetFps).apply();
        }
    }

    private void setChipSelected(TextView chip, boolean selected) {
        chip.setTextColor(selected ? Color.rgb(9, 25, 26) : Color.rgb(205, 217, 230));
        chip.setBackground(rounded(selected ? Color.rgb(98, 220, 192) : Color.rgb(23, 34, 48),
                selected ? 0 : Color.rgb(39, 56, 75), dp(11)));
    }

    private void applyProfile() {
        if (!requirementsMet || !scopeConfirmed) { refreshRequirements(); return; }
        final int target = targetFps, rendered = renderedFps, outputRate = outputFps;
        String suffix = " " + target + " " + rendered + " " + outputRate
                + " && settings --user 0 put secure frameforce_target_fps " + target
                + " && settings --user 0 put secure frameforce_rendered_fps " + rendered
                + " && settings --user 0 put secure frameforce_output_fps " + outputRate
                + " && settings --user 0 put secure frameforce_enabled 1"
                + " && echo 'Profile applied. Enable FrameForce for Game Cube in LSPosed, then restart Game Cube.'";
        runAssetTask("frameforce_apply.sh", "Applying " + target + " → " + rendered + " → " + outputRate + " profile…", suffix);
    }

    private void refreshRequirements() {
        requirementsMet = false;
        if (apply != null) apply.setEnabled(false);
        if (requirementStatus != null) requirementStatus.setText("Checking root, LSPosed, Meta Mount, module and Game Cube…");
        worker.execute(new Runnable() {
            @Override public void run() {
                String result;
                try {
                    File script = new File(getFilesDir(), "frameforce_requirements.sh");
                    copyAsset("frameforce_requirements.sh", script);
                    result = runRoot("/system/bin/sh '" + script.getAbsolutePath() + "'");
                } catch (Throwable error) { result = "Requirements check failed: " + error; }
                final String message = result;
                final boolean ready = result.contains("ALL_REQUIREMENTS_MET");
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        requirementsMet = ready;
                        requirementStatus.setText(message + (ready
                                ? "\n\nLSPosed scope must include com.vivo.gamecube."
                                : "\n\nTap here to check again after fixing requirements."));
                        updateApplyEnabled();
                    }
                });
            }
        });
    }

    private void updateApplyEnabled() {
        boolean ready = requirementsMet && scopeConfirmed;
        if (apply != null) {
            apply.setEnabled(ready);
            apply.setAlpha(ready ? 1f : 0.45f);
        }
    }

    private void disableHooks() {
        runRootTask("Disabling hooks…", "settings --user 0 put secure frameforce_enabled 0"
                + " && echo 'Hooks disabled. Restart Game Cube for the change to take effect.'");
    }

    private void confirmRevert() {
        new AlertDialog.Builder(this)
                .setTitle("Revert FrameForce?")
                .setMessage("This overwrites the four Game Cube databases with their first backup, disables the LSPosed hook, and disables the XML overlay for the next reboot. Database changes made after that backup will be discarded.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Revert", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface dialog, int which) {
        runAssetTask("frameforce_restore.sh", "Restoring the original settings…", "");
                    }
                })
                .show();
    }

    private void runAssetTask(final String asset, final String progress, final String suffix) {
        setBusy(true, progress);
        worker.execute(new Runnable() {
            @Override public void run() {
                String message;
                try {
                    if ("frameforce_apply.sh".equals(asset)) {
                        File requirements = new File(getFilesDir(), "frameforce_requirements.sh");
                        copyAsset("frameforce_requirements.sh", requirements);
                        String check = runRoot("/system/bin/sh '" + requirements.getAbsolutePath() + "'");
                        if (!check.contains("ALL_REQUIREMENTS_MET")) {
                            final String failure = check;
                            runOnUiThread(new Runnable() {
                                @Override public void run() {
                                    requirementsMet = false;
                                    requirementStatus.setText(failure);
                                    output.setText("Apply blocked: requirements are not met.");
                                    updateApplyEnabled();
                                    disable.setEnabled(true);
                                    revert.setEnabled(true);
                                }
                            });
                            return;
                        }
                    }
                    File script = new File(getFilesDir(), asset);
                    copyAsset(asset, script);
                    String command = "/system/bin/sh '" + script.getAbsolutePath() + "'" + suffix;
                    message = runRoot(command);
                } catch (Throwable error) { message = "Could not run the operation.\n" + error; }
                showResult(message);
            }
        });
    }

    private void runRootTask(final String progress, final String command) {
        setBusy(true, progress);
        worker.execute(new Runnable() {
            @Override public void run() {
                String message;
                try { message = runRoot(command); }
                catch (Throwable error) { message = "Could not run the operation.\n" + error; }
                showResult(message);
            }
        });
    }

    private String runRoot(String command) throws Exception {
        Process process = new ProcessBuilder("su", "-c", command).redirectErrorStream(true).start();
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        InputStream in = process.getInputStream();
        byte[] buffer = new byte[4096];
        int n;
        while ((n = in.read(buffer)) != -1) bytes.write(buffer, 0, n);
        int code = process.waitFor();
        String body = new String(bytes.toByteArray(), StandardCharsets.UTF_8).trim();
        return (code == 0 ? "Done" : "Failed (exit " + code + ")")
                + (body.isEmpty() ? "" : "\n" + body);
    }

    private void setBusy(final boolean busy, final String message) {
        apply.setEnabled(!busy && requirementsMet && scopeConfirmed);
        apply.setAlpha(!busy && requirementsMet && scopeConfirmed ? 1f : 0.45f);
        disable.setEnabled(!busy);
        revert.setEnabled(!busy);
        output.setText(message);
    }

    private void showResult(final String message) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                output.setText(message);
                updateApplyEnabled();
                disable.setEnabled(true);
                revert.setEnabled(true);
            }
        });
    }

    private void copyAsset(String asset, File destination) throws Exception {
        InputStream in = getAssets().open(asset);
        FileOutputStream out = new FileOutputStream(destination);
        try {
            byte[] buffer = new byte[8192];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
        } finally { in.close(); out.close(); }
    }

    private Button button(String title, int backgroundColor, int textColor) {
        Button b = new Button(this);
        b.setText(title);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        b.setTextColor(textColor);
        b.setBackground(rounded(backgroundColor, 0, dp(15)));
        return b;
    }

    private TextView label(String value, int size, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        return view;
    }

    private GradientDrawable rounded(int color, int stroke, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        if (stroke != 0) drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    private LinearLayout.LayoutParams params(int width, int height, int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(width, height);
        p.topMargin = dp(top);
        p.bottomMargin = dp(bottom);
        return p;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override protected void onDestroy() {
        worker.shutdownNow();
        super.onDestroy();
    }
}
