package com.bababoi.frameforce;

import android.app.Application;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.util.Log;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** LSPosed hooks for Game Cube. It does not spoof temperatures or alter kernel thermal controls. */
public final class FrameForceHook implements IXposedHookLoadPackage {
    private static final String TAG = "FrameForce";
    private static final String GAME_CUBE = "com.vivo.gamecube";
    private static volatile Context context;

    @Override public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lp) {
        if (!GAME_CUBE.equals(lp.packageName)) return;
        hook("android.app.Application", lp, "onCreate", new Class<?>[0], new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam p) {
                if (p.thisObject instanceof Application) context = (Application) p.thisObject;
                Log.i(TAG, "injected into " + lp.processName);
            }
        });

        hook("ua.c", lp, "a", new Class<?>[] { Context.class, String.class }, allowThirdParty(1));
        hook("ua.c", lp, "b", new Class<?>[] { Context.class, String.class }, allowThirdParty(1));
        hook("com.vivo.gameassistant.utils.e0", lp, "Y0",
                new Class<?>[] { Context.class, String.class }, allowThirdParty(1));
        hook("com.vivo.gameassistant.frameinterpolation.h", lp, "F0", new Class<?>[0], forceTrue());
        hook("com.vivo.gameassistant.frameinterpolation.h", lp, "i1", new Class<?>[0], forceTrue());
        hook("com.vivo.gameassistant.superresolution.j", lp, "j1", new Class<?>[0], forceTrue());
        hook("com.vivo.gameassistant.superresolution.p", lp, "l", new Class<?>[0], forceTrue());
        hook("com.vivo.gameassistant.homegui.sideslide.panels.performance.modeshift.n", lp,
                "n", new Class<?>[0], forceTrue());
        hook("com.vivo.gameassistant.homegui.sideslide.panels.performance.modeshift.n", lp,
                "m", new Class<?>[0], forceTrue());
        hook("com.vivo.gameassistant.homegui.sideslide.panels.performance.modeshift.n", lp,
                "v", new Class<?>[] { boolean.class }, forceMonsterArgOnly());
        hook("com.vivo.gameassistant.homegui.sideslide.panels.performance.modeshift.a", lp,
                "a", new Class<?>[0], forceTrue());
        hook("com.vivo.gameassistant.entity.MonsterPlusEvent", lp, "isMonster",
                new Class<?>[0], forceTrue());

        Class<?> sr = XposedHelpers.findClassIfExists("com.vivo.gameassistant.superresolution.j", lp.classLoader);
        if (sr != null) {
            hook(sr, "A0", new Object[] { sr }, forceTrue());
            hook(sr, "B0", new Object[] { sr, boolean.class }, forceMonsterArg());
            Class<?>[] sig = new Class<?>[] { Context.class, String.class, boolean.class, boolean.class };
            hook("com.vivo.gameassistant.superresolution.j", lp, "G1", sig, srCommand(false));
            hook("com.vivo.gameassistant.superresolution.j", lp, "H1", sig, srCommand(false));
            hook(sr, "m0", new Object[] { sr, Context.class, String.class, boolean.class, boolean.class }, srCommand(true));
        }

        for (String method : new String[] { "f", "g" }) {
            hook("com.vivo.common.algorithem.b", lp, method,
                    new Class<?>[] { Context.class, String.class, String.class }, avoidVsrMemcConflict());
        }
        hook("com.vivo.common.utils.l0", lp, "b",
                new Class<?>[] { Context.class, boolean.class, int.class, int.class, int.class, int.class },
                forceInterpolationCommand());
        hook("a8.a", lp, "b", new Class<?>[] { InputStream.class }, patchStream(false));
        hook("g7.a", lp, "b", new Class<?>[] { InputStream.class }, patchStream(true));
    }

    private static boolean enabled() {
        Context c = context;
        if (c == null) return false;
        try { return Settings.Secure.getInt(c.getContentResolver(), "frameforce_enabled", 0) == 1; }
        catch (Throwable ignored) { return false; }
    }

    private static int profileValue(String key, int fallback) {
        Context c = context;
        if (c == null) return fallback;
        try { return Settings.Secure.getInt(c.getContentResolver(), key, fallback); }
        catch (Throwable ignored) { return fallback; }
    }

    private static void hook(String name, XC_LoadPackage.LoadPackageParam lp, String method,
                             Class<?>[] signature, XC_MethodHook callback) {
        try {
            Object[] args = new Object[signature.length + 1];
            System.arraycopy(signature, 0, args, 0, signature.length);
            args[signature.length] = callback;
            XposedHelpers.findAndHookMethod(name, lp.classLoader, method, args);
            Log.i(TAG, "hooked " + name + "#" + method);
        } catch (Throwable t) { Log.i(TAG, "skip " + name + "#" + method + ": " + t); }
    }

    private static void hook(Class<?> type, String method, Object[] signature, XC_MethodHook callback) {
        try {
            Object[] args = new Object[signature.length + 1];
            System.arraycopy(signature, 0, args, 0, signature.length);
            args[signature.length] = callback;
            XposedHelpers.findAndHookMethod(type, method, args);
            Log.i(TAG, "hooked " + type.getName() + "#" + method);
        } catch (Throwable t) { Log.i(TAG, "skip " + type.getName() + "#" + method + ": " + t); }
    }

    private static XC_MethodHook forceTrue() {
        return new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam p) {
                if (enabled()) p.setResult(Boolean.TRUE);
            }
        };
    }

    private static XC_MethodHook allowThirdParty(final int packageArg) {
        return new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam p) {
                if (!enabled() || p.args.length <= packageArg) return;
                String pkg = String.valueOf(p.args[packageArg]);
                if (isThirdParty(pkg)) p.setResult(Boolean.TRUE);
            }
        };
    }

    private static boolean isThirdParty(String pkg) {
        Context c = context;
        if (c == null || pkg == null || pkg.length() == 0) return false;
        try {
            ApplicationInfo ai = c.getPackageManager().getApplicationInfo(pkg, 0);
            return (ai.flags & ApplicationInfo.FLAG_SYSTEM) == 0;
        } catch (Throwable ignored) { return false; }
    }

    private static XC_MethodHook forceMonsterArg() {
        return new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                if (enabled() && p.args.length > 1) p.args[1] = Boolean.TRUE;
            }
        };
    }

    private static XC_MethodHook avoidVsrMemcConflict() {
        return new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam p) {
                if (!enabled()) return;
                String key = String.valueOf(p.args.length > 1 ? p.args[1] : "").toLowerCase();
                String item = String.valueOf(p.args.length > 2 ? p.args[2] : "").toLowerCase();
                if (key.contains("vsr") || key.contains("memc") || item.contains("vsr") || item.contains("memc"))
                    p.setResult(Boolean.FALSE);
            }
        };
    }

    private static XC_MethodHook forceInterpolationCommand() {
        return new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                String game = currentGame();
                if (!enabled() || p.args.length < 6 || (game != null && game.length() > 0 && !isThirdParty(game))) return;
                // Follow Game Cube's valid game-specific values. Only enable an off command
                // and fill missing arguments; rewriting every call caused unstable pacing.
                if (Boolean.TRUE.equals(p.args[1])) return;
                p.args[1] = Boolean.TRUE;
                if (((Integer) p.args[2]).intValue() < 0) p.args[2] = Integer.valueOf(3);
                if (((Integer) p.args[4]).intValue() <= 0)
                    p.args[4] = Integer.valueOf(profileValue("frameforce_rendered_fps", 72));
                if (((Integer) p.args[5]).intValue() <= 0)
                    p.args[5] = Integer.valueOf(profileValue("frameforce_output_fps", 144));
                Log.i(TAG, "enabled interpolation with Game Cube profile; filled missing values only");
            }
        };
    }

    private static String currentGame() {
        Context c = context;
        if (c == null) return null;
        try { return Settings.System.getString(c.getContentResolver(), "current_game_package"); }
        catch (Throwable ignored) { return null; }
    }

    private static XC_MethodHook forceMonsterArgOnly() {
        return new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                if (enabled() && p.args.length > 0) p.args[0] = Boolean.TRUE;
            }
        };
    }

    private static XC_MethodHook srCommand(final boolean selfInArgs) {
        return new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                if (!enabled()) return;
                Object instance = selfInArgs && p.args.length > 0 ? p.args[0] : p.thisObject;
                if (instance == null) return;
                try {
                    XposedHelpers.setBooleanField(instance, "x", true);
                    XposedHelpers.setIntField(instance, "u", 144);
                } catch (Throwable ignored) { }
            }
        };
    }

    private static XC_MethodHook patchStream(final boolean interpolation) {
        return new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                if (!enabled() || p.args.length == 0 || !(p.args[0] instanceof InputStream)) return;
                try {
                    ByteArrayOutputStream out = new ByteArrayOutputStream(65536);
                    byte[] buffer = new byte[8192];
                    int n;
                    InputStream in = (InputStream) p.args[0];
                    while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
                    byte[] raw = out.toByteArray();
                    byte[] changed = interpolation ? patchFiXml(raw) : patchSrXml(raw);
                    p.args[0] = new ByteArrayInputStream(changed);
                    Log.i(TAG, (interpolation ? "patched frame interpolation" : "patched super resolution") + " XML");
                } catch (Throwable t) { Log.i(TAG, "XML patch failed: " + t); }
            }
        };
    }

    private static byte[] patchSrXml(byte[] raw) throws Exception {
        String xml = new String(raw, StandardCharsets.UTF_8);
        if (!xml.contains("frameDepress") || !xml.contains("</games>")) return raw;
        Matcher items = Pattern.compile("<item\\b[^>]*/>").matcher(xml);
        StringBuffer patched = new StringBuffer();
        while (items.find()) {
            String item = items.group();
            item = setAttr(item, "state", "2");
            item = setAttr(item, "ultraResolution", "2K");
            items.appendReplacement(patched, Matcher.quoteReplacement(item));
        }
        items.appendTail(patched);
        String result = patched.toString();
        Set<String> have = packageNames(result, "item");
        StringBuilder add = new StringBuilder();
        for (ApplicationInfo ai : thirdPartyApps()) {
            if (have.contains(ai.packageName)) continue;
            add.append("    <item pkgName=\"").append(xmlEscape(ai.packageName)).append("\" label=\"")
                    .append(xmlEscape(label(ai))).append("\" channel=\"#\" state=\"2\" frameDepress=\"72\" frameInter=\"144\" monsterFrameDepress=\"72\" monsterFrameInter=\"144\" ultraResolution=\"2K\" index=\"3\"/>\n");
        }
        result = result.replace("</games>", add + "</games>");
        return setVersion(result).getBytes(StandardCharsets.UTF_8);
    }

    private static byte[] patchFiXml(byte[] raw) throws Exception {
        String xml = new String(raw, StandardCharsets.UTF_8);
        if (!xml.contains("boostFrameValues") || !xml.contains("</games>")) return raw;
        Matcher games = Pattern.compile("(?s)<game\\b[^>]*>.*?</game>").matcher(xml);
        StringBuffer patched = new StringBuffer();
        while (games.find()) {
            String game = games.group();
            int target = profileValue("frameforce_target_fps", 90);
            int rendered = profileValue("frameforce_rendered_fps", 72);
            int output = profileValue("frameforce_output_fps", 144);
            String boost = "<boostFrameValues><item gameFps=\"" + target
                    + "\" depressValue=\"" + rendered + "\" frameInterValue=\"" + output
                    + "\"/></boostFrameValues>";
            // Keep the OEM/reference profile list whenever it already exists.
            if (!game.contains("<boostFrameValues>")) game = game.replace("</game>", boost + "</game>");
            games.appendReplacement(patched, Matcher.quoteReplacement(game));
        }
        games.appendTail(patched);
        String result = patched.toString();
        Set<String> have = packageNames(result, "game");
        StringBuilder add = new StringBuilder();
        for (ApplicationInfo ai : thirdPartyApps()) {
            if (have.contains(ai.packageName)) continue;
            int target = profileValue("frameforce_target_fps", 90);
            int rendered = profileValue("frameforce_rendered_fps", 72);
            int output = profileValue("frameforce_output_fps", 144);
            add.append("    <game pkgName=\"").append(xmlEscape(ai.packageName)).append("\" label=\"")
                    .append(xmlEscape(label(ai))).append("\" channel=\"#\" index=\"3\" supportSDK=\"false\">")
                    .append("<boostFrameValues><item gameFps=\"").append(target).append("\" depressValue=\"")
                    .append(rendered).append("\" frameInterValue=\"").append(output).append("\"/></boostFrameValues>")
                    .append("<optiPowerValues><item gameFps=\"120\" depressValue=\"60\" frameInterValue=\"120\"/></optiPowerValues>")
                    .append("<frameRateTips><item gameFps=\"90\" tipStringName=\"super_high\" tipString=\"90fps\"/></frameRateTips></game>\n");
        }
        result = result.replace("</games>", add + "</games>");
        return setVersion(result).getBytes(StandardCharsets.UTF_8);
    }

    private static String setAttr(String tag, String name, String value) {
        Pattern p = Pattern.compile("\\b" + Pattern.quote(name) + "=\"[^\"]*\"");
        Matcher m = p.matcher(tag);
        String replacement = name + "=\"" + value + "\"";
        if (m.find()) return m.replaceFirst(Matcher.quoteReplacement(replacement));
        return tag.substring(0, tag.length() - 2) + " " + replacement + "/>";
    }

    private static String setVersion(String xml) {
        return xml.replaceFirst("<version>[^<]*</version>", "<version>99</version>");
    }

    private static Set<String> packageNames(String xml, String element) {
        Set<String> names = new HashSet<String>();
        Matcher m = Pattern.compile("<" + element + "\\b[^>]*\\bpkgName=\"([^\"]+)\"").matcher(xml);
        while (m.find()) names.add(m.group(1));
        return names;
    }

    private static List<ApplicationInfo> thirdPartyApps() {
        List<ApplicationInfo> result = new ArrayList<ApplicationInfo>();
        Context c = context;
        if (c == null) return result;
        try {
            for (ApplicationInfo ai : c.getPackageManager().getInstalledApplications(0)) {
                if ((ai.flags & ApplicationInfo.FLAG_SYSTEM) == 0 && !ai.packageName.equals(GAME_CUBE)
                        && !ai.packageName.equals("com.bababoi.frameforce")) result.add(ai);
            }
        } catch (Throwable t) { Log.i(TAG, "package enumeration failed: " + t); }
        return result;
    }

    private static String label(ApplicationInfo ai) {
        try { return String.valueOf(context.getPackageManager().getApplicationLabel(ai)); }
        catch (Throwable ignored) { return ai.packageName; }
    }

    private static String xmlEscape(String value) {
        return value.replace("&", "&amp;").replace("<", "&lt;").replace("\"", "&quot;").replace("'", "&apos;");
    }
}
