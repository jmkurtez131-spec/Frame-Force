#!/system/bin/sh
export PATH=/system/bin:/system/xbin:/vendor/bin:/product/bin:$PATH
B=/data/user/0/com.vivo.gamecube/databases
DATA=/data/adb/frameforce
MOD=/data/adb/modules/frameforce
LEGACY_MOD=/data/adb/modules/fo-frameforce
BACKUP=${1:-$DATA/backups/baseline}
LEGACY_BACKUP=0

if [ ! -f "$BACKUP/complete" ] && [ -z "$1" ]; then
  # Migrate from the timestamped backup layout used by the earlier beta.
  LEGACY=$(ls -1dt "$DATA/backups"/20* 2>/dev/null | tail -n 1)
  if [ -n "$LEGACY" ]; then BACKUP=$LEGACY; LEGACY_BACKUP=1; fi
fi
if [ ! -d "$BACKUP" ]; then echo "backup not found: $BACKUP" >&2; exit 2; fi
[ "$LEGACY_BACKUP" = "1" ] || [ -f "$BACKUP/complete" ] || { echo "backup is incomplete: $BACKUP" >&2; exit 1; }
command -v nsenter >/dev/null 2>&1 || { echo "nsenter is required" >&2; exit 1; }
command -v nsenter >/dev/null 2>&1 || { echo "nsenter is required" >&2; exit 1; }
command -v sqlite3 >/dev/null 2>&1 || { echo "sqlite3 is required on PATH" >&2; exit 1; }

for db in game_cube.db super_resolution_list.db frame_inter_list.db support_dimension_list.db; do
  [ -f "$BACKUP/$db" ] || { echo "backup missing: $BACKUP/$db" >&2; exit 1; }
  nsenter -t 1 -m -- test -f "$B/$db" || { echo "Game Cube database missing: $B/$db" >&2; exit 1; }
done

am force-stop com.vivo.gamecube 2>/dev/null
settings --user 0 put secure frameforce_enabled 0
settings --user 0 put secure frameforce_target_fps 90
settings --user 0 put secure frameforce_rendered_fps 72
settings --user 0 put secure frameforce_output_fps 144
[ ! -d "$MOD" ] || touch "$MOD/disable"
[ ! -d "$LEGACY_MOD" ] || touch "$LEGACY_MOD/disable"
for db in game_cube.db super_resolution_list.db frame_inter_list.db support_dimension_list.db; do
  nsenter -t 1 -m -- sqlite3 "$B/$db" ".restore '$BACKUP/$db'" || exit 1
done
echo "Restored Game Cube databases from $BACKUP"
echo "FrameForce hook disabled. If the module existed, reboot to remove its XML overlay."
