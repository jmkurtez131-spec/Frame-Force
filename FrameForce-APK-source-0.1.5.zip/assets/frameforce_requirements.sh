#!/system/bin/sh
export PATH=/system/bin:/system/xbin:/vendor/bin:/product/bin:$PATH
FAILED=0
check() {
  if [ "$2" = "1" ]; then echo "[ready] $1"; else echo "[missing] $1"; FAILED=1; fi
}

[ "$(id -u)" = "0" ] && ROOT=1 || ROOT=0
check "Root access" "$ROOT"

MOD=/data/adb/modules/frameforce
if [ -f "$MOD/module.prop" ] && grep -q '^id=frameforce$' "$MOD/module.prop" && [ ! -e "$MOD/disable" ]; then MODULE=1; else MODULE=0; fi
check "FrameForce KernelSU module active" "$MODULE"

LSPOSED=0
METAMODULE=0
for d in /data/adb/modules/*; do
  [ -d "$d" ] || continue
  [ -e "$d/disable" ] && continue
  [ -f "$d/module.prop" ] || continue
  id=$(sed -n 's/^id=//p' "$d/module.prop" | head -n 1 | tr 'A-Z' 'a-z')
  name=$(sed -n 's/^name=//p' "$d/module.prop" | head -n 1 | tr 'A-Z' 'a-z')
  case "$id $name" in *lsposed*) LSPOSED=1 ;; esac
  case "$id $name" in *meta*|*overlayfs*|*mount*) [ "$id" = "frameforce" ] || METAMODULE=1 ;; esac
done
check "LSPosed framework active" "$LSPOSED"
check "Meta Mount / overlay metamodule active" "$METAMODULE"

command -v nsenter >/dev/null 2>&1 && NSENTER=1 || NSENTER=0
command -v sqlite3 >/dev/null 2>&1 && SQLITE=1 || SQLITE=0
check "nsenter available" "$NSENTER"
check "sqlite3 available" "$SQLITE"

B=/data/user/0/com.vivo.gamecube/databases
DBS=1
for db in game_cube.db super_resolution_list.db frame_inter_list.db support_dimension_list.db; do
  nsenter -t 1 -m -- test -f "$B/$db" || DBS=0
done
check "Game Cube databases initialized" "$DBS"

if [ "$FAILED" = "0" ]; then echo ALL_REQUIREMENTS_MET; exit 0; fi
echo "Open Game Cube once if its databases are missing. Tap this panel to check again."
exit 1
