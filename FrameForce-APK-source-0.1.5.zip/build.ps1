param(
    [string]$KeystorePath = $env:FRAMEFORCE_KEYSTORE,
    [string]$StorePassword = $env:FRAMEFORCE_KEYSTORE_PASSWORD,
    [string]$KeyAlias = $(if ($env:FRAMEFORCE_KEY_ALIAS) { $env:FRAMEFORCE_KEY_ALIAS } else { 'frameforce' })
)

$ErrorActionPreference = 'Stop'
if (-not $KeystorePath -or -not $StorePassword) {
    throw 'Set FRAMEFORCE_KEYSTORE and FRAMEFORCE_KEYSTORE_PASSWORD, or pass -KeystorePath and -StorePassword.'
}

$sdk = if ($env:ANDROID_SDK_ROOT) { $env:ANDROID_SDK_ROOT } elseif ($env:ANDROID_HOME) { $env:ANDROID_HOME } else { Join-Path $env:USERPROFILE 'AppData\Local\Android\Sdk' }
$jdkRoot = if ($env:JAVA_HOME) { $env:JAVA_HOME } else { 'C:\Program Files\Android\Android Studio\jbr' }
$studioJdk = Join-Path $jdkRoot 'bin'
$env:JAVA_HOME = $jdkRoot
$env:PATH = "$studioJdk;$env:PATH"
$java = Join-Path $studioJdk 'java.exe'
$javac = Join-Path $studioJdk 'javac.exe'
$buildTools = Join-Path $sdk 'build-tools\36.0.0'
$androidJar = Join-Path $sdk 'platforms\android-35\android.jar'
$aapt2 = Join-Path $buildTools 'aapt2.exe'
$d8Jar = Join-Path $buildTools 'lib\d8.jar'
$zipalign = Join-Path $buildTools 'zipalign.exe'
$apksigner = Join-Path $buildTools 'apksigner.bat'

foreach ($path in @($java, $javac, $androidJar, $aapt2, $d8Jar, $zipalign, $apksigner, $KeystorePath)) {
    if (-not (Test-Path -LiteralPath $path)) { throw "Required build input not found: $path" }
}

$root = $PSScriptRoot
$out = [System.IO.Path]::GetFullPath((Join-Path $root '..\..\work\frameforce-apk-build'))
$classes = Join-Path $out 'classes'
$stubs = Join-Path $out 'compile-stubs'
$dex = Join-Path $out 'dex'
New-Item -ItemType Directory -Force -Path $classes, $stubs, $dex | Out-Null
foreach ($dir in @($classes, $stubs, $dex)) { Get-ChildItem -LiteralPath $dir -Force | Remove-Item -Recurse -Force }

$stubFiles = @(Get-ChildItem -LiteralPath (Join-Path $root 'compile-stubs') -Filter '*.java' -Recurse | ForEach-Object { $_.FullName })
& $javac -encoding UTF-8 -source 8 -target 8 -bootclasspath $androidJar -d $stubs $stubFiles
if ($LASTEXITCODE -ne 0) { throw 'Compiling Xposed API stubs failed.' }

& $javac -encoding UTF-8 -source 8 -target 8 -bootclasspath $androidJar -classpath "$stubs;$androidJar" -d $classes (Join-Path $root 'src\com\bababoi\frameforce\MainActivity.java') (Join-Path $root 'src\com\bababoi\frameforce\FrameForceHook.java')
if ($LASTEXITCODE -ne 0) { throw 'javac failed.' }

$classFiles = @(Get-ChildItem -LiteralPath $classes -Filter '*.class' -Recurse | ForEach-Object { $_.FullName })
if ($classFiles.Count -eq 0) { throw 'javac produced no class files.' }
& $java -cp $d8Jar com.android.tools.r8.D8 --lib $androidJar --min-api 29 --output $dex $classFiles
if ($LASTEXITCODE -ne 0) { throw 'D8 failed.' }

$base = Join-Path $out 'base.apk'
& $aapt2 link -o $base -I $androidJar --manifest (Join-Path $root 'AndroidManifest.xml') --min-sdk-version 29 --target-sdk-version 34 --version-code 6 --version-name 0.1.5
if ($LASTEXITCODE -ne 0) { throw 'aapt2 link failed.' }

$unsigned = Join-Path $out 'unsigned.apk'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$sourceZip = [System.IO.Compression.ZipFile]::OpenRead($base)
$targetStream = [System.IO.File]::Open($unsigned, [System.IO.FileMode]::Create)
$targetZip = [System.IO.Compression.ZipArchive]::new($targetStream, [System.IO.Compression.ZipArchiveMode]::Create, $false)
try {
    foreach ($entry in $sourceZip.Entries) {
        $compression = [System.IO.Compression.CompressionLevel]::Optimal
        if ($entry.FullName -eq 'resources.arsc') { $compression = [System.IO.Compression.CompressionLevel]::NoCompression }
        $copy = $targetZip.CreateEntry($entry.FullName, $compression)
        $input = $entry.Open()
        $output = $copy.Open()
        try { $input.CopyTo($output) } finally { $output.Dispose(); $input.Dispose() }
    }
    $filesToAdd = @(
        [pscustomobject]@{ Source = (Join-Path $dex 'classes.dex'); Target = 'classes.dex' },
        [pscustomobject]@{ Source = (Join-Path $root 'assets\frameforce_apply.sh'); Target = 'assets/frameforce_apply.sh' },
        [pscustomobject]@{ Source = (Join-Path $root 'assets\frameforce_restore.sh'); Target = 'assets/frameforce_restore.sh' },
        [pscustomobject]@{ Source = (Join-Path $root 'assets\frameforce_requirements.sh'); Target = 'assets/frameforce_requirements.sh' },
        [pscustomobject]@{ Source = (Join-Path $root 'assets\xposed_init'); Target = 'assets/xposed_init' },
        [pscustomobject]@{ Source = (Join-Path $root 'META-INF\xposed\scope.list'); Target = 'META-INF/xposed/scope.list' }
    )
    foreach ($pair in $filesToAdd) {
        $copy = $targetZip.CreateEntry($pair.Target, [System.IO.Compression.CompressionLevel]::Optimal)
        $input = [System.IO.File]::OpenRead($pair.Source)
        $output = $copy.Open()
        try { $input.CopyTo($output) } finally { $output.Dispose(); $input.Dispose() }
    }
} finally {
    $targetZip.Dispose()
    $targetStream.Dispose()
    $sourceZip.Dispose()
}

$aligned = Join-Path $out 'aligned.apk'
& $zipalign -f 4 $unsigned $aligned
if ($LASTEXITCODE -ne 0) { throw 'zipalign failed.' }

$apk = Join-Path $root 'FrameForce.apk'
& $apksigner sign --ks $KeystorePath --ks-type PKCS12 --ks-key-alias $KeyAlias --ks-pass "pass:$StorePassword" --key-pass "pass:$StorePassword" --out $apk $aligned
if ($LASTEXITCODE -ne 0) { throw 'APK signing failed.' }
& $apksigner verify --verbose $apk
if ($LASTEXITCODE -ne 0) { throw 'APK signature verification failed.' }
Get-Item -LiteralPath $apk | Select-Object FullName, Length
